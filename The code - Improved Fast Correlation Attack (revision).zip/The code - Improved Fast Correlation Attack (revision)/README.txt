# README

This repository contains the code used to obtain some of our results in the paper "Improved fast correlation attack using multiple linear approximations and its application on SOSEMANUK".

- `1. MILP model for SOSEMANUK` contains the MILP model for searching for the linear approximation trails of SOSEMANUK.

- `2. Calculate the 1417 correlations of function T` contains the process of calculating the 1417 linear approximations of function T.

- `3. Linear approximation trails with correlation greater than 2^-22` contains the process of searching for the linear approximation trails of SOSEMANUK with correlation greater than 2^-22.

- `4. Construct Table 3` contains the process of constructing Table 3.
 
- `5. Experimental Verification Correlation` contains the process of verificating the experimental correlations of the 16 linear approximations of SOSEMANUK given in Table VI by using 2^47 samples.

- `6. Sosemanuk-Calculate attack complexity.py` contains the process of calculating the success probability and attack complexity. 

We give the following process of searching for linear approximation of SOSEMANUK.

Step 1: We use the the MILP model to search for the linear approximation trails of SOSEMANUK. Then we obtain the 10678 linear approximation trails of SOSEMANUK and store the results in the file "SOSEMANUK_Line_Trail.txt", where the number of different mask tuples (Gamma_1, Gamma_2, Gamma_3) is 1417. The 1417 different mask tuples (Gamma_1, Gamma_2, Gamma_3) are stored in file "The different masks Gamma_1,Gamma_2,Gamma_3.txt".

Step 2: We calculate the linear approximations of composite function T(x,y)=x+Trans^-1(y) with the 1417 mask tuples (Gamma_1, Gamma_2, Gamma_3) and store the results in the file "Calculate the 1417 correlations of function T.txt". Then we obtain 79 linear approximations of function T with the correlation greater than 2^{-20} and store the results in the file "79 linear approximations of T.xlsx".

Setp 3: For the 79 linear approximations of function T, we search for the linear approximation trails of SOSEMANUK with the correlation greater than 2^{-22} in the 10678 linear approximation trails of SOSEMANUK.  Then we obtain the 16 linear approximation trails of SOSEMANUK with the correlation greater than 2^{-21.41} and store the results in the file "Result.txt", as given in Table II in our paper.

Step 4: For the 16 mask tuples (Gamma_3, Gamma_4, Gamma_5) shown in Table II, we exhaust the 27 kinds of (Gamma_1, Gamma_2) and calculate the corresponding correlation ρ_FSM, respectively. Then we can obtain the 16 linear approximation trails and store the results in the file "Table 3.txt", as given in Table III in our paper.

