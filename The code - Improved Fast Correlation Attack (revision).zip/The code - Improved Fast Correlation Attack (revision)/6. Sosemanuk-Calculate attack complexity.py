from scipy.stats import norm
from scipy.special import comb,perm
from scipy import stats
import math
import numpy as np

n = 320
c = 2**(-20.848)
p2 = 0.5
Min = n
Min_N = 0
Min_T = 0
Min_Beta = -1
Min_th = 0
Min_thp = 0
thp = 0

max1 = n
Success_rate = 0.99
max_B = -1
max_B1 = -1
max_B2 = -1
max_M = -1
max_k = -1
max_T1 = -1
max_T2 = -1
max_T3 = -1
max_N = -1
max_N2 = -1
max_p = -1
max_q = -1
max_Memory = -1
max_d = -1
mmax_T = -1
mmax_r = -1


def f(f_p, f_q, f_beta):
    s = 0
    for k in range(f_q, f_beta + 1):
        s += comb(f_beta, k) * (f_p ** k) * ((1 - f_p) ** (f_beta - k))
    s = Success_rate - s
    return s


def bisection(f, a, b, f_q, f_beta,  eps):
    """
    the Bisection Method
    """
    fa, fb = f(a, f_q, f_beta), f(b, f_q, f_beta)
    while abs(b - a) > eps:
        mid = (a + b) / 2
        fmid = f(mid, f_q, f_beta)

        if fa * fmid < 0:  # [a,mid]
            b, fb = mid, fmid
        elif fb * fmid < 0:  # [mid,b]
            a, fa = mid, fmid
        else:  # f(mid) = 0
            return mid

    return (a + b) / 2

def qiu_p(p, q, q_Beta):

    s = 0
    for k in range(q, q_Beta+1):
        s += comb(q_Beta, k) * (p**k) * ((1-p)**(q_Beta-k))

    print("Solution", p, q, q_Beta, s)
    return s


Fing = norm.ppf(1 - Success_rate) ** 2

p = Success_rate

max_xxxx = -1

for xxxx in range(1, 2):
    mm = 16

    for k in range(2, 4):
        c_K = c ** (2 * k)
        for B in range(n):  # B = B1 + B2
            for B1 in range(1, B+1):
                B2 = B - B1

                if B2 < 0:
                    continue
                d = int(mm / (2**B2))
                q = int(n/B1)+1
                if q > d:
                    continue

                if B2 > math.log2(mm/d) or B2 > math.log2(mm/q):
                    continue

                p = bisection(f, 0, 1, q, d, 0.000001)

                for rr in range(60):
                    r = 2 ** rr
                    if q > r:
                        continue

                    m = ((norm.ppf(p) - norm.ppf((2 ** (-B1 - 1 + math.log(r, 2))))) ** 2) / c_K  # D
                    if m > 2 ** ((n-B) / int(math.log2(k))):
                        continue
                    Mk = (((m) ** (1 / (1 + int(math.log(k, 2))))) ) * (2 ** ((n-B) / (1 + int(math.log(k, 2)))))    # N

                    T1 = xxxx * Mk

                    if Mk < 0:
                        continue

                    if math.log2(r) > 100:
                        continue
                    if math.log2(comb(r, q)) > 140:
                        continue
                    if math.log2(comb(mm, q)) > 140:
                        continue

                    T2 = (m + B1 * (2 ** B1))

                    T3 = comb(mm, q) * (((q * B1)**3) + comb(r, q) * math.factorial(q))

                    Memory = max(2*Mk, 2 ** B1)
                    maxx_M = math.log(m, 2)
                    if maxx_M < 0:
                        continue
                    maxx_N = math.log(Mk*2, 2)
                    maxx_T = math.log(T3 + T2 + T1, 2)
                    maxx_T1 = math.log(T1, 2)
                    maxx_T2 = math.log(T2, 2)
                    maxx_T3 = math.log(T3, 2)
                    maxx_Memory = math.log(Memory, 2)
                    maxx = max(maxx_Memory, maxx_T, maxx_N)

                    if max1 > maxx:
                        max_k = k
                        max1 = maxx
                        max_M = maxx_M
                        max_N2 = maxx_N
                        max_N = math.log(Mk, 2)
                        max_Memory = maxx_Memory
                        max_T1 = maxx_T1
                        max_T2 = maxx_T2
                        max_T3 = maxx_T3
                        max_B = B
                        max_B1 = B1
                        max_B2 = B2
                        mmax_T = maxx_T
                        mmax_r = r
                        max_q = q
                        max_p = p
                        max_d = d
                        max_xxxx = xxxx

print("r:2^{}, k:{}, B1:{}, B2:{}, n-B:{}, attack complexity: 2^{}".format(math.log(mmax_r, 2), max_k, max_B1, max_B2, n-max_B, max1))
print(n-max_q*max_B1, math.log2(2**(-max_B1-1+math.log(mmax_r, 2))))
print(norm.ppf(max_p), max_B1, -max_B1 - 1 + math.log(mmax_r, 2), ((norm.ppf(max_p) - norm.ppf((2 ** (-max_B1 - 1 + math.log(mmax_r, 2))))) ** 2), math.log2((norm.ppf(max_p) - norm.ppf((2 ** (-max_B1 - 1 + math.log(mmax_r, 2))))) ** 2), -math.log2(c ** (2 * max_k)))
print("Solution p:{}, q:{}, d:{}, p_suc:{}".format(max_p, max_q, max_d, qiu_p(max_p, max_q, max_d)))

print("The parity check equations D: 2^{},".format(max_M))
print("N: 2^{},\n".format(max_N))
print("The time complexity of the preprocessing phase is T1: 2^{}".format(max_T1))
print("The time complexity of the processing phase is T2: 2^{} ".format(max_T2))
print("The time complexity of the processing phase is T3: 2^{} ".format(max_T3))
print("The time complexity is T=T1+T2+T3: 2^{},".format(mmax_T))
print("data complexity: 2^{}, memory complexity: 2^{}".format(max_N2, max_Memory))