from gurobipy import *
import time
import math
TimeLimit = 1000000
Mm = 16
weight = [
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0]

def three_way_or(M, x, y, z): #z = x V y

    for i in range(len(x)):
        M.addConstr(- x[i] - y[i] + z[i] >= -1)
        M.addConstr(- x[i] + y[i] + z[i] >= 0)
        M.addConstr(x[i] - y[i] + z[i] >= 0)
        M.addConstr(x[i] + y[i] - z[i] >= 0)

def funcADD(M, x, y, z, s): # Add2: x[32],y[32] -> z[32]     s[33]

    M.addConstr(s[len(x)] == 0)

    for i in range(len(x)):
        M.addConstr(s[i + 1] - z[i] - x[i] + y[i] + s[i] >= 0)
        M.addConstr(s[i + 1] - z[i] + x[i] - y[i] + s[i] >= 0)
        M.addConstr(s[i + 1] + z[i] - x[i] - y[i] + s[i] >= 0)

        M.addConstr(s[i + 1] + z[i] + x[i] - y[i] - s[i] >= 0)
        M.addConstr(s[i + 1] + z[i] - x[i] + y[i] - s[i] >= 0)
        M.addConstr(s[i + 1] - z[i] + x[i] + y[i] - s[i] >= 0)

        M.addConstr(- s[i + 1] + z[i] + x[i] + y[i] + s[i] >= 0)
        M.addConstr(- s[i + 1] - z[i] - x[i] - y[i] - s[i] >= -4)



def ConstrainsModel(flag_q, solution_i, Gamma_value, G_value):

    #StartTime = time.time()
    M = Model()
    M.setParam("TimeLimit",TimeLimit)

    Gamma = []        # Gamma[7][32] = Gamma[6][32] U Fing[32]
    Gamma1_or_2 = []
    Add_s = []        # Add_s[3][33]

    for i in range(7):  # Gamma[7][32] = Gamma[6][32] U Fing[32]
        Gamma.append([])
        for k in range(32):
            Gamma[i].append(M.addVar(vtype=GRB.BINARY, name="Gamma[" + str(i) + "][" + str(k) + "]"))

    for i in range(32):
        Gamma1_or_2.append(M.addVar(vtype=GRB.BINARY, name="Gamma1_or_2[" + str(i) + "]"))

    for i in range(3):  # Add_s[3][33]
        Add_s.append([])
        for k in range(33):
            Add_s[i].append(M.addVar(vtype=GRB.BINARY, name="Add_s[" + str(i) + "][" + str(k) + "]"))

    M.addConstr(Gamma[2][flag_q + 25] == 1)
    for i in range(flag_q + 26, 32):
        M.addConstr(Gamma[2][i] == 0)

    M.addConstr(Gamma[2][flag_q] == 1)
    for i in range(flag_q + 1, 7):
        M.addConstr(Gamma[2][i] == 0)


    for i in range(len(Gamma_value)):
        constrain = LinExpr()
        Const = 0

        flag = [1,4,5,2,3]
        for k in range(len(flag)):
            for j in range(32):
                if (Gamma_value[i][flag[k]] >> j) & 0x1 == 1:
                    constrain -= Gamma[flag[k]][j]
                    Const += 1
                else:
                    constrain += Gamma[flag[k]][j]

        M.addConstr(constrain >= 1 - Const)

    three_way_or(M, Gamma[1], Gamma[2], Gamma1_or_2)

    funcADD(M, Gamma[1], Gamma[4], Gamma[0], Add_s[0])
    funcADD(M, Gamma[5], Gamma[0], Gamma[2], Add_s[1])
    funcADD(M, Gamma[3], Gamma[6], Gamma[1], Add_s[2])

    obj1 = LinExpr()
    for i in range(len(Add_s)): # Add_s[3][33]
        for k in range(1, 32):
            obj1 += Add_s[i][k]
    for i in range(len(Gamma1_or_2)):  # Add_s[3][33]
        obj1 += Gamma1_or_2[i]

    M.setObjective(obj1, GRB.MINIMIZE)

    M.update()

    LPname = "SOSEMANUK_Line.lp"
    M.write(LPname)

    M.Params.MIPFocus = 1

    M.optimize()
    ConstrainsName_sol = "SOSEMANUK_Line.sol"
    M.write(ConstrainsName_sol)

    fp1 = open("SOSEMANUK_Line_Trail.txt", "a")
    fp1.write("{")

    Gamma_value.append([])
    G_temp = []

    for i in range(len(Gamma)):     #Gamma[solution_i][5][32]
        temp = 0
        for k in range(len(Gamma[i])):
            temp ^= round(Gamma[i][k].x) << k
        Gamma_value[solution_i].append(temp)
        fp1.write("{:#010x},".format(temp))
        if (i >= 1) and (i <= 3):
            G_temp.append(temp)

    #EndTime = time.time()
    fp1.write("}, ")
    fp1.write("// {}-th sulution {},\n".format(solution_i, M.objVal))
    fp1.close()

    if G_temp not in G_value:
        G_value.append(G_temp)
        fp = open("The different masks Gamma_1,Gamma_2,Gamma_3.txt", "a")
        for i in G_temp:
            fp.write("{:#010x},".format(i))
        fp.write("\n")
        fp.close()

    return Gamma_value

def main():
    Gamma_value = []
    G_value = []
    solution = 1 << 50
    flag_q = 0
    fp1 = open("SOSEMANUK_Line_Trail.txt", "a")
    fp1.write("( Gamma_0,   Gamma_1,   Gamma_2,   Gamma_3,   Gamma_4,   Gamma_5,   Phi ):\n")
    fp1.close()

    fp = open("The different masks Gamma_1,Gamma_2,Gamma_3.txt", "a")
    fp.write("(Gamma_1, Gamma_2, Gamma_3):\n")
    fp.close()

    for i in range(solution):
        Gamma_value = ConstrainsModel(flag_q, i, Gamma_value, G_value)

if __name__ == '__main__':
    main()
