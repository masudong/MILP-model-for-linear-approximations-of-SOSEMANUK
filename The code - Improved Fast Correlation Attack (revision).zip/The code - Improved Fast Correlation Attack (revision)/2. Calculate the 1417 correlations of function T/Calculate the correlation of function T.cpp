#include<stdio.h>
#include<time.h>
#include<math.h>
#include <string.h>
#include <stdlib.h>
typedef unsigned char u8;
typedef unsigned int u32;
typedef unsigned __int64 u64;
typedef signed __int64 s64;
u8 wt2[256]={
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0};
void matrix_Gao(int t1, int t2, int t, FILE *fp, int Gao_mask[0x10][0x10][0x10], int Gao_sum[0x10][0x10], int Gao[0x10][0x10][0x10][2][2])
{													 
	
	int i,j,k;
	 
	int M[2][2][2]={0};
	for(i=0;i<2;i++) for(j=0;j<2;j++) for(k=0;k<2;k++) M[i][j][k] = 0;
	int CC[2][2];
	int c0,c1,x1,x2,f,temp;
	 
	for(c0=0;c0<2;c0++)for(x1=0;x1<16;x1++)for(x2=0;x2<16;x2++) 
	{	
		
		temp = x1+x2+c0;
		c1 = (temp>>4);   
		f = wt2[(t & (temp)) ^ (t1&x1 ) ^ (t2&x2)];  
		M[f][c1][c0]++;
	}
 	int flag = 0; 
  	for(c1=0;c1<2;c1++)
  	{
  		for(c0=0;c0<2;c0++)
	  	{
	  		CC[c1][c0] = M[0][c1][c0] - M[1][c1][c0];  
		} 
	}
	if(((CC[0][0]+CC[1][0])!= 0) || ((CC[0][1]+CC[1][1])!= 0))
	{
		Gao_mask[t2][t][Gao_sum[t2][t]] = t1; 
 		fprintf(fp,"{");			
		for(c1=0;c1<2;c1++)
	  	{
	  		fprintf(fp,"{");
	  		for(c0=0;c0<2;c0++)
		  	{ 
		  		Gao[t2][t][Gao_sum[t2][t]][c1][c0]=CC[c1][c0]; 
		  		fprintf(fp,"%d,",CC[c1][c0]);
			}
			fprintf(fp,"},");
		}
		fprintf(fp,"},//0x%x,0x%x;0x%x\n",t1, t2,t); 
		Gao_sum[t2][t]++;
	} 
}
void matrix_Di(int t1, int t2, int t, FILE *fp, int Di_mask[0x10][0x10][0x10], int Di_sum[0x10][0x10], int Di[0x10][0x10][0x10][2][2])
{													 
	
	int i,j,k; 
	int M[2][2][2]={0};
	for(i=0;i<2;i++) for(j=0;j<2;j++) for(k=0;k<2;k++) M[i][j][k] = 0;
	int CC[2][2];
	int c0,c1,x1,x2,f,temp;
	 
	for(c0=0;c0<2;c0++)for(x1=0;x1<16;x1++)for(x2=0;x2<16;x2++) 
	{	
		
		temp = x1+x2+c0;
		c1 = (temp>>4);   
		f = wt2[(t & (temp)) ^ (t1&x1 ) ^ (t2&x2)];  
		M[f][c1][c0]++;
	}
 	int flag = 0; 
  	for(c1=0;c1<2;c1++)
  	{
  		for(c0=0;c0<2;c0++)
	  	{
	  		CC[c1][c0] = M[0][c1][c0] - M[1][c1][c0];  
		} 
	}
	if((CC[0][0] != 0) || (CC[1][0] != 0))
	{
		Di_mask[t2][t][Di_sum[t2][t]] = t1;
 		fprintf(fp,"{");			
		for(c1=0;c1<2;c1++)
	  	{
	  		fprintf(fp,"{");
	  		for(c0=0;c0<2;c0++)
		  	{ 
		  		Di[t2][t][Di_sum[t2][t]][c1][c0]=CC[c1][c0]; 
		  		fprintf(fp,"%d,",CC[c1][c0]);
			}
			fprintf(fp,"},");
		}
		fprintf(fp,"},//0x%x,0x%x;0x%x\n",t1, t2,t); 
		Di_sum[t2][t]++;
	} 
} 
void matrix_Zhong(int t1, int t2, int t, FILE *fp, int Zhong_mask[0x10][0x10][0x10], int Zhong_sum[0x10][0x10], int Zhong[0x10][0x10][0x10][2][2]) 
{													 
	
	int i,j,k; 
	int M[2][2][2]={0};
	for(i=0;i<2;i++) for(j=0;j<2;j++) for(k=0;k<2;k++) M[i][j][k] = 0;
	int CC[2][2];
	int c0,c1,x1,x2,f,temp;
	 
	for(c0=0;c0<2;c0++)for(x1=0;x1<16;x1++)for(x2=0;x2<16;x2++)
	{	 
		temp = x1+x2+c0;
		c1 = (temp>>4);   
		f = wt2[(t & (temp)) ^ (t1&x1 ) ^ (t2&x2)];  
		M[f][c1][c0]++;
	}
 	int flag = 0; 
  	for(c1=0;c1<2;c1++)
  	{
  		for(c0=0;c0<2;c0++)
	  	{
	  		CC[c1][c0] = M[0][c1][c0] - M[1][c1][c0]; 
			if(CC[c1][c0] != 0) 
				flag = 1;
		} 
	}
	if(flag == 1)
	{ 
		Zhong_mask[t2][t][Zhong_sum[t2][t]] = t1;
 		fprintf(fp,"{");			
		for(c1=0;c1<2;c1++)
	  	{
	  		fprintf(fp,"{");
	  		for(c0=0;c0<2;c0++)
		  	{ 
		  		Zhong[t2][t][Zhong_sum[t2][t]][c1][c0]=CC[c1][c0]; 
		  		fprintf(fp,"%d,",CC[c1][c0]);
			}
			fprintf(fp,"},");
		}
		fprintf(fp,"},//0x%x,0x%x;0x%x\n",t1, t2,  t); 
		Zhong_sum[t2][t]++;
	} 
} 
void Marix_cheng(s64 H2[2], int M[2][2], s64 HH2[2], int &sum8)  
{
	s64 temp[2];  
	int j,k,flag8; 
	for(j=0;j<2;j++)
	{
		temp[j] = 0;
		for(k=0;k<2;k++)
		{
			if((H2[k] != 0) && (M[k][j] != 0))
				temp[j] += H2[k] * M[k][j];
		}
	}
	
	flag8 = 0; 
	for(j=0;j<2;j++)
	{
	
		if(temp[j] % 0x100 !=0)  
		{ 
			flag8 = 1;
			break;
		}
	}
 
	sum8 = 0;
	if(flag8 == 0) 
	{
		sum8+=1;  
		for(j=0;j<2;j++) HH2[j] = temp[j]/(1<<8); 
	}  
	else for(j=0;j<2;j++) HH2[j] = temp[j];
}
 
void test_d_max(int &shiji, int &tongji, u32 t1[0x10000], double result[0x10000][2], u32 t2, u32 t,
int Gao[0x10][0x10][0x10][2][2], int Gao_sum[0x10][0x10],int Gao_mask[0x10][0x10][0x10],
int Di[0x10][0x10][0x10][2][2], int Di_sum[0x10][0x10],int Di_mask[0x10][0x10][0x10],
int Zhong[0x10][0x10][0x10][2][2], int Zhong_sum[0x10][0x10], int Zhong_mask[0x10][0x10][0x10])
{	 
	int i0,i1,i2,i3,i4,i5,i6,i7,i,j;
	s64 H2[2]={1,1}; 
	s64 temp[8][2]={0},temp2[2]={0,0}; 
	s64 sum=0; 
	int sum8[8]={0},x[8]={0};
	u32 Max_d;
	double Max=-100,Temp;
	int sign; 
   	
	shiji = 0;
   	
	for(i0=0;i0<Gao_sum[(t2>>28)&0xf][(t>>28)&0xf];i0++)
	//for(i0=0;i0<1;i0++)
	{
		x[7] = Gao_mask[(t2>>28)&0xf][(t>>28)&0xf][i0]; 
		Marix_cheng(H2, Gao[(t2>>28)&0xf][(t>>28)&0xf][i0], temp[0], sum8[0]);
		if((temp[0][0] == 0) && (temp[0][1] == 0)) continue; 
			
		for(i1=0;i1<Zhong_sum[(t2>>24)&0xf][(t>>24)&0xf];i1++)
		//for(i1=4;i1<5;i1++)
		{
			   
			x[6] = Zhong_mask[(t2>>24)&0xf][(t>>24)&0xf][i1];
			Marix_cheng(temp[0], Zhong[(t2>>24)&0xf][(t>>24)&0xf][i1], temp[1], sum8[1]);
			if((temp[1][0] == 0) && (temp[1][1] == 0)) continue; 
			
			for(i2=0;i2<Zhong_sum[(t2>>20)&0xf][(t>>20)&0xf];i2++) 
			{
			  
				 
				x[5] = Zhong_mask[(t2>>20)&0xf][(t>>20)&0xf][i2];
				Marix_cheng(temp[1], Zhong[(t2>>20)&0xf][(t>>20)&0xf][i2], temp[2], sum8[2]);
				if((temp[2][0] == 0) && (temp[2][1] == 0)) continue; 
				
				for(i3=0;i3<Zhong_sum[(t2>>16)&0xf][(t>>16)&0xf];i3++)
				//for(i3=3;i3<4;i3++)
				{
				  
					x[4] = Zhong_mask[(t2>>16)&0xf][(t>>16)&0xf][i3];
					Marix_cheng(temp[2], Zhong[(t2>>16)&0xf][(t>>16)&0xf][i3], temp[3], sum8[3]); 
					if((temp[3][0] == 0) && (temp[3][1] == 0)) continue;
			
					for(i4=0;i4<Zhong_sum[(t2>>12)&0xf][(t>>12)&0xf];i4++)
					//for(i4=3;i4<4;i4++)
					{
					   
						x[3] = Zhong_mask[(t2>>12)&0xf][(t>>12)&0xf][i4];
						Marix_cheng(temp[3], Zhong[(t2>>12)&0xf][(t>>12)&0xf][i4], temp[4], sum8[4]); 
						if((temp[4][0] == 0) && (temp[4][1] == 0)) continue;
						
						for(i5=0;i5<Zhong_sum[(t2>>8)&0xf][(t>>8)&0xf];i5++) 
						{
						  
							x[2] = Zhong_mask[(t2>>8)&0xf][(t>>8)&0xf][i5];
							Marix_cheng(temp[4], Zhong[(t2>>8)&0xf][(t>>8)&0xf][i5], temp[5], sum8[5]);
							if((temp[5][0] == 0) && (temp[5][1] == 0)) continue;
							
							 	
							for(i6=0;i6<Zhong_sum[(t2>>4)&0xf][(t>>4)&0xf];i6++)
							//for(i6=7;i6<10;i6++)
							{   
								x[1] = Zhong_mask[(t2>>4)&0xf][(t>>4)&0xf][i6];
								Marix_cheng(temp[5], Zhong[(t2>>4)&0xf][(t>>4)&0xf][i6], temp[6], sum8[6]);
								if((temp[6][0] == 0) && (temp[6][1] == 0)) continue;
							  
								for(i7=0;i7<Di_sum[t2&0xf][t&0xf];i7++)
								//for(i7=0;i7<1;i7++)
								{
									  
									x[0] = Di_mask[t2&0xf][t&0xf][i7];
									Marix_cheng(temp[6], Di[t2&0xf][t&0xf][i7], temp[7], sum8[7]);
									 
									tongji++; 
									if(temp[7][0] == 0) continue;  
									if(temp[7][0] > 0)  result[shiji][1]=1;
								 	else if(temp[7][0] < 0) 
									{
										temp[7][0] = -temp[7][0];  
									 	result[shiji][1]=-1;
									}  
									
								 	sum = 0; 
								 	for(i=0;i<8;i++) sum += sum8[i];
								 	
							 		t1[shiji] = (x[7] << 28) ^ (x[6] << 24) ^ (x[5] << 20) ^ (x[4] << 16) ^ 
							 		 		(x[3] << 12) ^ (x[2] << 8) ^ (x[1] << 4) ^ x[0]; 
							 		result[shiji][0] = (log(temp[7][0])/log(2)-64 + 8*sum);  
									
									/*
									if(result[shiji][1] > 0)
										printf("0x%08x, 2^%f, \n", t1[shiji], result[shiji][0]);
									else
										printf("0x%08x, -2^%f, \n", t1[shiji], result[shiji][0]);
									*/	
									shiji++; 
								}
							}
						}
					}
				}
			} 
		}  
	}
}
 
void yuchuli_Addition32_2(int Gao[0x10][0x10][0x10][2][2], int Gao_sum[0x10][0x10],int Gao_mask[0x10][0x10][0x10],
int Di[0x10][0x10][0x10][2][2], int Di_sum[0x10][0x10],int Di_mask[0x10][0x10][0x10],
int Zhong[0x10][0x10][0x10][2][2], int Zhong_sum[0x10][0x10], int Zhong_mask[0x10][0x10][0x10])
{
	int t1, t2, t;
 	int sum=0;
 	  
 	FILE *fp_Gao,*fp_Di,*fp_Zhong;
 	fp_Gao = fopen("H_(x,yz)-250.txt","w");
 	fp_Di = fopen("L_(x,yz)-1234.txt","w");
 	fp_Zhong = fopen("I_(x,yz)-1234.txt","w");
 	int Gao_Sum=0,Di_Sum=0,Zhong_Sum=0;
 	int i;
 	
 	for(t=0;t<16;t++)
 	{
 		for(t2=0;t2<16;t2++)
 		{ 
 			 
			Gao_sum[t2][t]=0;
			Di_sum[t2][t]=0;
			Zhong_sum[t2][t]=0;
			//fprintf(fp,"C[0x%x][0x%x][0x%x]={", t2, t3, t);
			for(t1=0;t1<16;t1++)
			{ 
				matrix_Gao(t1, t2, t, fp_Gao, Gao_mask, Gao_sum, Gao);
				matrix_Di(t1, t2, t, fp_Di, Di_mask, Di_sum, Di);
				matrix_Zhong(t1, t2, t, fp_Zhong, Zhong_mask, Zhong_sum, Zhong); 
			}
			//fprintf(fp,"},\n");
			if(Gao_sum[t2][t] != 0)
			{
				fprintf(fp_Gao,"number:%d,\n",Gao_sum[t2][t]); 
				Gao_Sum += Gao_sum[t2][t];
			}
				 
			if(Di_sum[t2][t] != 0)
			{
				fprintf(fp_Di,"number:%d,\n",Di_sum[t2][t]);
				Di_Sum += Di_sum[t2][t];
			}
			
			if(Zhong_sum[t2][t] != 0)
			{
				fprintf(fp_Zhong,"number:%d,\n",Zhong_sum[t2][t]);
				Zhong_Sum += Zhong_sum[t2][t];
			}
			 
		}
	}
	fclose(fp_Gao);
	fclose(fp_Di);
	fclose(fp_Zhong);
	printf("Gao_Sum:%d, 2^%.3f, Zhong_Sum:%d, 2^%.3f, Di_Sum:%d, 2^%.3f\n",Gao_Sum,log(Gao_Sum)/log(2), 
			Zhong_Sum,log(Zhong_Sum)/log(2),Di_Sum,log(Di_Sum)/log(2)); 
}
#define ROTL32(word32, offset) ((word32 << offset) | (word32 >> (32 - offset))) 
u32 Multiply(u32 x) 
{
	u32 MUL;
	MUL = 0x54655307 * x;
	return MUL;
}
double Cor_Trans(u32 a, u32 b, int &sign) 
{
	s64 i;
	u32 temp;
	int Walsh;
	s64 sum = 0;
	u32 b_rot = ROTL32(b, 25);
	//printf("0x%08x\n",b_rot);
	for(i=0;i<0x100000000;i++)
	{
		temp = ((b_rot & Multiply(i)) ^ (a & i)); 
		if(wt2[(temp ^ (temp >> 8) ^ (temp >> 16) ^ (temp >> 24)) & 0xff]) sum--;
		else sum++;
	}
	if(sum > 0) sign = 1;
	else if(sum < 0){ sign = -1; sum = -sum;
	}
	else sign = 0;
	
	return (log(sum)/log(2)-32);
} 
int main()
{
 	int Gao[0x10][0x10][0x10][2][2]={0};  
 	int Gao_sum[0x10][0x10] = {0};  
 	int Gao_mask[0x10][0x10][0x10]={0}; 
  	
	int Di[0x10][0x10][0x10][2][2]={0};
 	int Di_sum[0x10][0x10] = {0};
	int Di_mask[0x10][0x10][0x10]={0}; 
	
	int Zhong[0x10][0x10][0x10][2][2]={0};
 	int Zhong_sum[0x10][0x10] = {0};
	int Zhong_mask[0x10][0x10][0x10]={0};  
	
	u32 Gamma1, Gamma2, Gamma3;
	  
	yuchuli_Addition32_2(Gao,Gao_sum,Gao_mask,Di,Di_sum,Di_mask,Zhong,Zhong_sum,Zhong_mask);
   	
	FILE *fp,*fp1;
	int i,j,sign_T,c_sum_sign;
	double T,c_sum; 
 	
	fp  = fopen("The different masks Gamma_1,Gamma_2,Gamma_3.txt","r");
	if(fp == NULL) printf("Open File Error!\n");   
	fscanf(fp,"( Gamma_1,   Gamma_2,   Gamma_3):\n");
	
 	for(i=0;i<1417;i++)
	{
		 
		fscanf(fp,"%x,%x,%x,\n",&Gamma1, &Gamma2, &Gamma3); 
		printf("\nGamma1:0x%08x, Gamma2:0x%08x, Gamma3:0x%08x,\n",Gamma1, Gamma2, Gamma3);
		
	 
		int shiji = 0,tongji=0;
		u32 t1[0x10000]={0};
		double result[0x10000][2]={0},sum=0; 
		
		test_d_max(shiji, tongji, t1, result, Gamma3, Gamma1, Gao, Gao_sum,Gao_mask,Di, Di_sum,Di_mask,Zhong,Zhong_sum,Zhong_mask);			
		printf("i:%d, tongji:%d,\n",i,tongji);
		for(j=0;j<shiji;j++)
		{ 
			T = Cor_Trans(t1[j], Gamma2, sign_T);
			if(sign_T == 0) continue;
			sum += pow(2,result[j][0] + T + 30) * result[j][1] * sign_T; 
		 	//printf("i:%d, j:%d, %f, %f, \n",i,j, result[j][0], T);
		}
		if(sum > 0) 
		{
			c_sum = log(sum)/log(2)-30; 
			c_sum_sign = 1;
		}
		else if(sum < 0) 
		{ 
			c_sum = log(-sum)/log(2)-30; 
			c_sum_sign = -1;	
		}
		else 
		{ 
			c_sum_sign = 0;
		}
		
		if(c_sum_sign != 0)
		{
			if(c_sum_sign > 0)
			{
				fp1 = fopen("Calculate the 1417 correlations of function T.txt","a");
				fprintf(fp1,"i:%d, 0x%08x, 0x%08x, 0x%08x: 2^%f\n",i, Gamma1, Gamma2, Gamma3, c_sum);	
				printf("i:%d, 0x%08x, 0x%08x, 0x%08x: 2^%f\n",i, Gamma1, Gamma2, Gamma3, c_sum);	
				fclose(fp1);
			}
				
			else
			{
				fp1 = fopen("Calculate the 1417 correlations of function T.txt","a");
				fprintf(fp1,"i:%d, 0x%08x, 0x%08x, 0x%08x: -2^%f\n",i, Gamma1, Gamma2, Gamma3, c_sum);
				printf("i:%d, 0x%08x, 0x%08x, 0x%08x: -2^%f\n",i, Gamma1, Gamma2, Gamma3, c_sum);
				fclose(fp1);
			}	
		} 
		else
		{
			fp1 = fopen("Calculate the 1417 correlations of function T.txt","a");
			fprintf(fp1,"i:%d, 0x%08x, 0x%08x, 0x%08x: 0\n",i, Gamma1, Gamma2, Gamma3);	
			printf("i:%d, 0x%08x, 0x%08x, 0x%08x: 0\n",i, Gamma1, Gamma2, Gamma3);	
			fclose(fp1);
		}
		 
	}   			  
	fclose(fp);
	return 0;
}
